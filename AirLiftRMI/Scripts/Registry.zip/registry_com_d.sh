CODEBASE="http://l040101-ws08.ua.pt/"$1"/classes/"
#CODEBASE="file://home/"$1"/Public/classes/"

java -Djava.rmi.server.codebase=$CODEBASE\
     -Djava.rmi.server.useCodebaseOnly=true\
     -Djava.security.policy=java.policy\
     Main.ServerRegisterRemoteObject -lp 22046 -rh l040101-ws08.ua.pt -rp 22047
